package Lesson3.Bulekova.HomeTask3;

import java.util.Arrays;

public class HomeTask3 {
    public static void main(String[] args) {
        fillArr();

    }

    public static void fillArr(){
        int [] arr = {1,5,3,2,11,4,5,2,4,8,9,1};

        for (int i = 0; i < arr.length; i++){

            if (arr[i]<6) {
                arr[i] = arr [i] * 2;}

        }


        System.out.println(Arrays.toString(arr));


    }
}
