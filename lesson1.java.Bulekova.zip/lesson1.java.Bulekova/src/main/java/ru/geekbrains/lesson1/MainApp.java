package ru.geekbrains.lesson1;

public class MainApp {
}
